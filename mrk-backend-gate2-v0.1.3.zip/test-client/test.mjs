const BASE=process.env.MRK_BASE_URL||"http://127.0.0.1:8787",TOKEN=process.env.MRK_DEV_TOKEN||"mrk_dev_test";
async function req(path,o={}){const r=await fetch(BASE+path,{...o,headers:{Authorization:`Bearer ${TOKEN}`,"Content-Type":"application/json",...(o.headers||{})}}),b=await r.json();console.log(`\n${o.method||"GET"} ${path} -> ${r.status}`);console.log(JSON.stringify(b,null,2));if(!r.ok)throw Error(JSON.stringify(b));return b;}
await req("/api/v1/health");await req("/api/v1/test/bootstrap",{method:"POST",body:"{}"});
const idem=`test-${Date.now()}`,c=await req("/api/v1/jobs",{method:"POST",headers:{"Idempotency-Key":idem},body:JSON.stringify({installation_id:"inst_test",text:"MRK Gate 1 test audio job.",voice:"Kore"})}),id=c.data.id;
await req("/api/v1/jobs/claim",{method:"POST",body:JSON.stringify({browser_id:"browser_test"})});
await req(`/api/v1/jobs/${id}/heartbeat`,{method:"POST",body:JSON.stringify({browser_id:"browser_test",status:"AUTOMATING"})});
await req(`/api/v1/jobs/${id}/complete`,{method:"POST",body:JSON.stringify({browser_id:"browser_test",duration_sec:1.2,sha256:"dev-test-sha256"})});
await req(`/api/v1/jobs/${id}`);await req("/api/v1/quota");console.log("\nGATE 1 BASIC FLOW: PASS");