# MRK Backend — Gate 2
Cloudflare Worker + D1 staging backend (R2 intentionally disabled for Gate 2).

## Scope
Validates health, bootstrap, job creation, idempotency, quota reserve/commit/refund, claim, heartbeat, complete/fail.
Gemini automation and real audio capture are intentionally excluded.

## Run
npm install
npm run db:migrate:local
npm run dev

In another terminal:
npm run test:client

DEV_TOKEN is development-only. Do not use in production.


## Gate 2 staging resource
- Worker: `mrk-backend-gate2`
- D1: `mrk-db-gate2`
- R2: intentionally not configured in this Gate 2 build.
- `DEV_TOKEN` must be configured as a Worker secret, not in `wrangler.toml`.
